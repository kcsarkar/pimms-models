#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>

void GenerateInFileName(double, double, char []);
void GenerateOutFileName(double, double, char []);

main()
{
 int i, j, k, count;
 double met, tmp, dE, cnt_avg;
 char  filename[50], filename2[50];
 double x1, x2, *E, *cnt;
 FILE *ftest = fopen("test.txt","w"); 

 E	= calloc(10000, sizeof(double));
 cnt	= calloc(10000, sizeof(double));

 met = 0.2;
 while(met<= 1.01){
     tmp = 6.0;
     while (tmp <=8.5){
         /* Reading the pimms spectra files */
         GenerateInFileName(met, tmp, filename);
	 FILE *fsp = fopen(filename, "r");
	 count = 0;
	 while(fscanf(fsp, "%lf %lf", &x1, &x2) != EOF){
	     if (x1 < 0.099) continue;
	     E[count]	= x1;
	     cnt[count]	= x2;
	     count ++;
	 } 
	 fclose(fsp);

	 /* determine the spacing and ask to average out */
	 dE	= E[1]-E[0];
	 if ( dE < 0.0021){
	     k	= 4;
	 }else if (dE < 0.0041){
	     k = 2;
	 }else{
	     k = 1;
	 }

	 /* Writting the desired spectra with dE = 0.008 keV */
         GenerateOutFileName(met, tmp, filename2);
	 FILE *fout = fopen(filename2, "w");
	 for (i=k-1; i< count; i = i+k){
	     cnt_avg	= 0.0;
	     for (j=0; j<k; j++) cnt_avg	+= cnt[i-j];
	     cnt_avg	= cnt_avg/k;
	     fprintf(fout,"%2.4f\t\t%2.4e\n", E[i], cnt_avg);
	 }
	 fclose(fout);
 
	 tmp	+= 0.05;
     }
     met += 0.200;
 }

 fclose(ftest);
}
/* *************************************** */
void GenerateInFileName(double met, double tmp, char filename[])
{
 char datafolder[20]="../models", model[10]="rs";

 sprintf(filename, "%s/%s%02d_%3d.mdl", datafolder, model, (int)(met*10), (int)(round(tmp*100)) );
// if ( (int)(round(met*100)) == 100)
//     sprintf(filename, "%s/%s%2d_%3d.mdl", datafolder, model, (int)(met*10), (int)(round(tmp*100)) ); 
}

/* *************************************** */
void GenerateOutFileName(double met, double tmp, char filename[])
{
 char datafolder[20]="./", model[10]="rs";

 sprintf(filename, "%s/%s%02d_%3d.mdl", datafolder, model, (int)(met*10), (int)(round(tmp*100)) );
// if ( (int)(round(met*100)) == 100)
//     sprintf(filename, "%s/%s%2d_%3d.mdl", datafolder, model, (int)(met*10), (int)(round(tmp*100)) ); 
}
